export const environment = {
  firebase: {
    apiKey: "FAKEKEY",
    authDomain: "ebt-tease.firebaseapp.com",
    projectId: "ebt-tease",
    storageBucket: "ebt-tease.appspot.com",
    messagingSenderId: "42042042069",
    appId: "1:42042042069:web:fakenonsense"
  }
};