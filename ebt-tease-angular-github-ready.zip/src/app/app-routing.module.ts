import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './pages/home/home.component';
import { ReportComponent } from './pages/report/report.component';
import { BenefitsComponent } from './pages/benefits/benefits.component';
import { ApplyComponent } from './pages/apply/apply.component';
import { FormComponent } from './pages/apply/form/form.component';
import { ReviewComponent } from './pages/apply/review/review.component';
import { StoreComponent } from './pages/store/store.component';
import { CartComponent } from './pages/store/cart/cart.component';
import { CheckoutComponent } from './pages/store/checkout/checkout.component';

const routes: Routes = [
  { path: '', component: HomeComponent },
  {
    path: 'apply', component: ApplyComponent, children: [
      { path: '', redirectTo: 'form', pathMatch: 'full' },
      { path: 'form', component: FormComponent },
      { path: 'review', component: ReviewComponent }
    ]
  },
  {
    path: 'store', component: StoreComponent, children: [
      { path: 'cart', component: CartComponent },
      { path: 'checkout', component: CheckoutComponent }
    ]
  },
  { path: 'benefits', component: BenefitsComponent },
  { path: 'report', component: ReportComponent },
  { path: '**', redirectTo: '' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {}
