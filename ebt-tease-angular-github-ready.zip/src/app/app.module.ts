import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { HomeComponent } from './pages/home/home.component';
import { ReportComponent } from './pages/report/report.component';
import { BenefitsComponent } from './pages/benefits/benefits.component';
import { ApplyComponent } from './pages/apply/apply.component';
import { FormComponent } from './pages/apply/form/form.component';
import { ReviewComponent } from './pages/apply/review/review.component';
import { StoreComponent } from './pages/store/store.component';
import { CartComponent } from './pages/store/cart/cart.component';
import { CheckoutComponent } from './pages/store/checkout/checkout.component';

@NgModule({
  declarations: [
    HomeComponent,
    ReportComponent,
    BenefitsComponent,
    ApplyComponent,
    FormComponent,
    ReviewComponent,
    StoreComponent,
    CartComponent,
    CheckoutComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [HomeComponent]
})
export class AppModule {}
