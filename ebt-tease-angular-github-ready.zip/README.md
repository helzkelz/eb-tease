# EBT Tease Angular

A satirical Angular web application parodying government services with chaotic UI, Firebase placeholders, Stripe mock integration, and OpenAI setup.

## 🔧 Setup Instructions

1. Clone the repo:
```bash
git clone https://github.com/YOUR-USERNAME/ebt-tease-angular.git
cd ebt-tease-angular
```

2. Install dependencies:
```bash
npm install
```

3. Start the development server:
```bash
ng serve
```

## 🔐 Environment Config (Replace these)

Edit `src/environments/environment.ts`:

```ts
export const environment = {
  firebase: {
    apiKey: "YOUR_FIREBASE_API_KEY",
    authDomain: "YOUR_FIREBASE_PROJECT.firebaseapp.com",
    projectId: "YOUR_FIREBASE_PROJECT",
    storageBucket: "YOUR_FIREBASE_PROJECT.appspot.com",
    messagingSenderId: "YOUR_SENDER_ID",
    appId: "YOUR_APP_ID"
  }
};
```

Add Stripe and OpenAI keys inside respective services/components when wiring those in.

---

**This repo is a meme. Use it wisely. Or don’t.** 😈
